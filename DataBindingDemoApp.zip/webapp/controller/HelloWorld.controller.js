sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("DataBindingDemoApp.controller.HelloWorld", {
		onInit:function(){
			var model = new sap.ui.model.json.JSONModel();
			
			model.setDefaultBindingMode("TwoWay");
			model.setData({name:'wangduxiu'});
			this.getView().setModel(model);
		},
		onPress:function(){
			this.getView().getModel().setProperty('/name', 'wangduxiu123');
		}
	});
});