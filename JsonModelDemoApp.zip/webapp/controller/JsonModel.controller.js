sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("JsonModelDemoApp.controller.JsonModel", {
		onInit: function(){
			//实例化
			var jsonModel = new JSONModel();
			//{name:'richard', sex:'male', job: 'developer'}
			jsonModel.setData({name:'wangduxiu', sex:'male', job: 'singer'});
			this.getView().setModel(jsonModel,"UserModel");
	
			//getData
			console.log(jsonModel.getData());
			
			//getJson
			console.log("get string json data:"+jsonModel.getJSON());
			
			//getProperty
			console.log("get name by Property:"+jsonModel.getProperty('/name'));
			
			
			var jsonModel2 = new JSONModel();
			jsonModel2.loadData('mockData/mock.json');
			jsonModel2.attachRequestCompleted(function(){
			})
			
			this.getView().setModel(jsonModel2, "jsonModel2");
			
		},
		
		setNewData: function(){
			var model = this.getView().getModel();
			model.setProperty("/technology", {tech1:'android', tech2:'IOS', tech3: 'SAPUI5'} )
		}
	});
});