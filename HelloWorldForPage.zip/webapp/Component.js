sap.ui.define(["sap/ui/core/UIComponent"], function (UIComponent) {
	return UIComponent.extend("HelloWorldForPage.Component", {
		metadata: {
			"rootView": "HelloWorldForPage.view.HelloWorldForPage"
		},
		init: function () {
			//init
			UIComponent.prototype.init.apply(this, arguments);
		}
	});
});