sap.ui.define(["sap/ui/core/mvc/Controller", "HelloWorldForPage/model/util"], function (Controller, util) {
	return Controller.extend("HelloWorldForPage.controller.HelloWorldForPage", {
		onInit: function () {

		},
		onBack: function (event) {
			var myPage = this.getView().byId('myPage');
			// myPage.setBusy(true);
			var testPosition = this.getView().byId('testPosition');

			//myPage.scrollTo(0, 2000);
			myPage.scrollToElement(testPosition, 2000);
		},
		sayHello: function (oEvent) {
			alert(util.generateRandom());
		},
		showLoading: function () {
			var myPage = this.getView().byId('myPage');
			myPage.setBusy(true);
		}
	});
});