sap.ui.define([],function(){
	return {
		generateRandom: function(){
			return Math.random();
		}
	};
});