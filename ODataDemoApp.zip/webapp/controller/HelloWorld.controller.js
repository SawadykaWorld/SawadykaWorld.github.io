sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/ODataModel"
], function(Controller, ODataModel) {
	"use strict";
	/**
      * 
     * $batch 
     * 
     * ODataModel 1.0
     * 
     * 
     * var oModel = new sap.ui.model.odata.ODataModel(sURL, {
				json: true
			});

			var batchChanges = [];
			for (var i = 0; i < arrTimesheets.length; i++) {
				batchChanges.push(oModel.createBatchOperation("url", "POST", {
					"TIMESHEETID": arrTimesheets[i].TIMESHEETID
				}));
			}

			oModel.addBatchChangeOperations(batchChanges);
			oModel.submitBatch(function(oData) {
				if (oData.__batchResponses[0].__changeResponses) {
					promise.resolve(oData);
				} else {
					promise.reject(oData);
				}
			}, function(oData) {
				promise.reject(oData);
			});
     */
	return Controller.extend("ODataDemoApp.controller.HelloWorld", {
		onInit: function() {
			var odataModel = new sap.ui.model.odata.v2.ODataModel('/DemoService/V2/(S(vwvvf40szqul4pkwqq50peal))/OData/OData.svc/', false);
			//odataModel.setUseBatch(false);
			//odataModel.setDefaultBindingMode("TwoWay");
			odataModel.setDeferredGroups(["MyGroup"]);
			this.getView().setModel(odataModel);

			odataModel.read("/Suppliers", {
				urlParameters: '&$format=json',
				success: function(oData) {
					console.log(oData);
				},
				error: function(oData) {

				}
			});
		},
		onChange: function(evt) {
			var oModel = this.getView().getModel();
			console.log(oModel.getProperty('/Products(0)'));
			var sPath = evt.getSource().getParent().getBindingContextPath();
			var sValue = evt.getParameter('value');
			oModel.update(sPath, {
				Name: sValue
			}, {
				groupId: 'MyGroup'
			});
			// 	oModel.update(sPath, {
			// 	Name: sValue
			// });

		},
		onPress: function(evt) {
			var oModel = this.getView().getModel();
			oModel.submitChanges({
				groupId: "MyGroup",
				success: this.mySuccessHandler,
				error: this.myErrorHandler
			});
		},
		
		reset: function(){
			var oModel = this.getView().getModel();
			oModel.resetChanges();
		},

		mySuccessHandler: function(oData) {
			console.log(oData);
			alert("ok");
		},

		myErrorHandler: function(oError) {
			alert("error");
		}
	});
});